#!/bin/bash

import sys
from library import *

# define csv files to read / write:
# NOTE: To run script change file paths / names here!
helixcsv = "../Roy_Projects/program_1B_THFfingerprints/25_chip_helices.csv"
eachloopcsv = "../Roy_Projects/program_1B_THFfingerprints/each_THF_loop_seq.csv"
eachreceptorcsv = "../Roy_Projects/program_1B_THFfingerprints/each_THF_receptor_seq.csv"
coreloopcsv = "../Roy_Projects/program_1B_THFfingerprints/against_core_loops.csv"
corereceptorcsv = "../Roy_Projects/program_1B_THFfingerprints/against_core_receptors.csv"
output1csv = "../Roy_Projects/program_1B_THFfingerprints/output_all_receptors_vs_core_loops.csv"
output2csv = "../Roy_Projects/program_1B_THFfingerprints/output_all_loops_vs_core_receptors.csv"

# Read in data
hname, hseq, hss = parse_helix_csv(helixcsv)
elseq, elname = parse_tecto_csv(eachloopcsv)
erseq, ername = parse_tecto_csv(eachreceptorcsv)
clseq, clname = parse_tecto_csv(coreloopcsv)
crseq, crname = parse_tecto_csv(corereceptorcsv)

clseq = clseq[:-1]
clname = clname[:-1]
crseq = crseq[:-1]
crname = crname[:-1]

# Generate core loops vs all receptor seqs:
counter = 0
outname = []
outseq = []
outss = []
for hnameit, hseqit, hssit in zip(hname, hseq, hss):
    for lseqit, lnameit in zip(clseq, clname):
        for rseqit, rnameit in zip(erseq, ername):
            newseqt, newsst = attach_receptor(rseqit, hseqit, hssit, -1)
            newseqt, newsst = attach_loop(lseqit, newseqt, newsst, newseqt.find('+'))
            newnamet = hnameit + ":" + lnameit + ":" + rnameit 
            outname.append(newnamet)
            outseq.append(newseqt)
            outss.append(newsst)
            counter += 1


data = {'name': outname, 'sequence': outseq, 'ss': outss}
df = pd.DataFrame(data, columns = ['name', 'sequence', 'ss'])
df.to_csv(output1csv, sep=",", index=False)


# Generate all loops vs core receptor seqs:
counter = 0
outname = []
outseq = []
outss = []
for hnameit, hseqit, hssit in zip(hname, hseq, hss):
    for lseqit, lnameit in zip(elseq, elname):
        for rseqit, rnameit in zip(crseq, crname):
            newseqt, newsst = attach_receptor(rseqit, hseqit, hssit, -1)
            newseqt, newsst = attach_loop(lseqit, newseqt, newsst, newseqt.find('+'))
            newnamet = hnameit + ":" + lnameit + ":" + rnameit 
            outname.append(newnamet)
            outseq.append(newseqt)
            outss.append(newsst)
            counter += 1


data = {'name': outname, 'sequence': outseq, 'ss': outss}
df = pd.DataFrame(data, columns = ['name', 'sequence', 'ss'])
df.to_csv(output2csv, sep=",", index=False)












