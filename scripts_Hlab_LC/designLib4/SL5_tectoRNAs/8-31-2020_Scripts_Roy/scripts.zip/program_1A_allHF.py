#!/bin/bash

import sys
from library import *

# define csv files to read / write:
# NOTE: To run script change file paths / names here!
helixcsv = "../Roy_Projects/program_1A_allTHF/3_chip_helices.csv"
loopcsv = "../Roy_Projects/program_1A_allTHF/each_THF_loop_seq.csv"
receptorcsv = "../Roy_Projects/program_1A_allTHF/each_THF_receptor_seq.csv"
outputcsv = "../Roy_Projects/program_1A_allTHF/program1_output_2352.csv"

# Read in data
hname, hseq, hss = parse_helix_csv(helixcsv)
lseq, lname = parse_tecto_csv(loopcsv)
rseq, rname = parse_tecto_csv(receptorcsv)

# Generate all seqs:
counter = 0
outname = []
outseq = []
outss = []
for hnameit, hseqit, hssit in zip(hname, hseq, hss):
    for lseqit, lnameit in zip(lseq, lname):
        for rseqit, rnameit in zip(rseq, rname):
            newseqt, newsst = attach_receptor(rseqit, hseqit, hssit, -1)
            newseqt, newsst = attach_loop(lseqit, newseqt, newsst, newseqt.find('+'))
            newnamet = hnameit + ":" + lnameit + ":" + rnameit 
            outname.append(newnamet)
            outseq.append(newseqt)
            outss.append(newsst)
            counter += 1

data = {'name': outname, 'sequence': outseq, 'ss': outss}
df = pd.DataFrame(data, columns = ['name', 'sequence', 'ss'])
df.to_csv(outputcsv, sep=",", index=False)
